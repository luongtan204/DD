import React from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
  FlatList,
  ScrollView,
  ActivityIndicator,
} from "react-native";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { useState, useEffect } from "react";

export default function App() {
  const [animals, setAnimals] = useState([]);
  const [animalType, setAnimalType] = useState([]);
  const [loading, setLoading] = useState(true);

  // GỌI 2 API cùng lúc
  useEffect(() => {
    Promise.all([
      fetch("https://682c590dd29df7a95be6a099.mockapi.io/api/1/animal").then((r) =>
        r.json()
      ),
      fetch("https://682c590dd29df7a95be6a099.mockapi.io/api/1/animalType").then((r) =>
        r.json()
      ),
    ])
      .then(([animalData, typeData]) => {
        setAnimals(animalData);
        setAnimalType(typeData);
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="purple" />
        <Text>Loading...</Text>
      </View>
    );
  }
  // ---- DỮ LIỆU ----
 {/*  const animalType = [
    { id: "1", animaltype: "Cat", image: require("./assets/cat.jpg") },
    { id: "2", animaltype: "Dog", image: require("./assets/dog.jpg") },
    { id: "3", animaltype: "Rabbit", image: require("./assets/rabbit.jpg") },
    { id: "4", animaltype: "Bird", image: require("./assets/luna.jpg") },
    { id: "5", animaltype: "Fish", image: require("./assets/pedro.jpg") },
    { id: "6", animaltype: "Hamster", image: require("./assets/olivia.jpg") },
  ];

  const animals = [
    {
      id: "1",
      name: "Olivia",
      gender: "Female",
      yob: "2 years",
      location: "125 Anywhere St, Any City",
      image: require("./assets/cat.jpg"),
    },
    {
      id: "2",
      name: "Pedro",
      gender: "Male",
      yob: "3 years",
      location: "125 Anywhere St, Any City",
      image: require("./assets/dog.jpg"),
    },
    {
      id: "3",
      name: "Luna",
      gender: "Female",
      yob: "3 years",
      location: "99 Flower Rd",
      image: require("./assets/rabbit.jpg"),
    },
    {
      id: "4",
      name: "Milo",
      gender: "Male",
      yob: "1 year",
      location: "321 Downtown Rd",
      image: require("./assets/dog.jpg"),
    },
    {
      id: "5",
      name: "Buddy",
      gender: "Male",
      yob: "2 years",
      location: "77 Sunny Ave",
      image: require("./assets/cat.jpg"),
    },
    {
      id: "6",
      name: "Lucy",
      gender: "Female",
      yob: "4 years",
      location: "45 Green St",
      image: require("./assets/rabbit.jpg"),
    },
  ];*/}

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.container}>
        {/* HEADER */}
        <View style={styles.header}>
          <Text style={styles.logo}>🐾</Text>
          <Text style={styles.title}>PET ADOPTION</Text>
        </View>

        {/* SEARCH */}
        <View style={styles.searchBox}>
          <TextInput
            placeholder="Search for pets..."
            placeholderTextColor="#999"
            style={styles.input}
          />
          <Image
            source={{
              uri: "https://cdn-icons-png.flaticon.com/512/622/622669.png",
            }}
            style={styles.searchIcon}
          />
        </View>

        {/* BANNER */}
        <View style={styles.banner}>
          <Text style={styles.bannerTitle}>
            Pet Adoption{"\n"}Made Easy
          </Text>
          <TouchableOpacity style={styles.btn}>
            <Text style={{ color: "white", fontWeight: "bold" }}>Adopt Now</Text>
          </TouchableOpacity>
        </View>

        {/* CATEGORY */}
        <View style={styles.categoryHeader}>
          <Text style={styles.catTitle}>Categories</Text>
          <Text style={styles.showAll}>Show All</Text>
        </View>

        <FlatList
          horizontal
          data={animalType}
          showsHorizontalScrollIndicator={true}
          renderItem={({ item }) => (
            <View style={styles.categoryItem}>
              <Image source={item.image} style={styles.categoryImg} />
              <Text style={styles.categoryText}>{item.animaltype}</Text>
            </View>
          )}
          keyExtractor={(item) => item.id}
        />

        {/* ANIMAL LIST */}
        <ScrollView>
          <View style={styles.animalContainer}>
            {animals.map((item) => (
              <View style={styles.animalCard} key={item.id}>
                <Image source={item.image} style={styles.animalImg} />
                <Text style={styles.animalName}>{item.name}</Text>
                <Text style={styles.animalInfo}>
                  {item.gender}, {item.yob}
                </Text>
                <Text style={styles.animalLoc}>{item.location}</Text>
              </View>
            ))}
          </View>
        </ScrollView>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

// ---- STYLES ----
const styles = StyleSheet.create({
  container: { flex: 1, padding: 15, backgroundColor: "#fff" },

  // HEADER
  header: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 15,
  },
  logo: { fontSize: 26, marginRight: 8 },
  title: { fontSize: 20, fontWeight: "bold", color: "#000" },

  // SEARCH
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 6,
    marginBottom: 15,
  },
  input: { flex: 1, fontSize: 16 },
  searchIcon: { width: 20, height: 20, tintColor: "#888" },

  // BANNER
  banner: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#f0e6ff",
    borderRadius: 15,
    padding: 15,
    marginBottom: 15,
  },
  bannerTitle: {
    fontWeight: "bold",
    fontSize: 18,
    color: "#000",
    lineHeight: 22,
  },
  btn: {
    backgroundColor: "#6C63FF",
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 10,
  },

  // CATEGORY
  categoryHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  catTitle: { fontSize: 18, fontWeight: "bold" },
  showAll: { color: "#6C63FF", fontWeight: "500" },
  categoryItem: { alignItems: "center", marginRight: 20, marginBottom: 400 },
  categoryImg: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginBottom: 5,
  },
  categoryText: { fontWeight: "500" },

  // ANIMAL
  animalContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  animalCard: {
    width: "48%",
    backgroundColor: "#fafafa",
    borderRadius: 10,
    padding: 10,
    marginBottom: 15,
  },
  animalImg: { width: "100%", height: 100, borderRadius: 10, marginBottom: 5 },
  animalName: { fontWeight: "bold", fontSize: 16 },
  animalInfo: { color: "gray", marginBottom: 3 },
  animalLoc: { fontSize: 12, color: "#6C63FF" },
});
